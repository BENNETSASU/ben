module.exports = {
    css: {
        extract: true
    }
}